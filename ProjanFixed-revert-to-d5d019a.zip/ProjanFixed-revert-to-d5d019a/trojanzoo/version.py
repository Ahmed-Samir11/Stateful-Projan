#!/usr/bin/env python3

__version__ = '1.0.8'
