#!/usr/bin/env python3

from trojanzoo.utils.environ import *

# Put implementation in utils to avoid import errors
